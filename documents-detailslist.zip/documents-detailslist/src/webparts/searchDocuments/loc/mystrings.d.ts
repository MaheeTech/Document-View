declare interface ISearchDocumentsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  LibraryUrlFieldLabel: string;
}

declare module 'SearchDocumentsWebPartStrings' {
  const strings: ISearchDocumentsWebPartStrings;
  export = strings;
}
