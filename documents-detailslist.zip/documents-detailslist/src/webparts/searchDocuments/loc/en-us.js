define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "LibraryUrlFieldLabel": "Add library absolute url:"
  }
});