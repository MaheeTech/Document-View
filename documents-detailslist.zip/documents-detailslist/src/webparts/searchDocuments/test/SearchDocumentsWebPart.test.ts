/// <reference types="mocha" />

import { assert } from 'chai';

describe('SearchDocumentsWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
