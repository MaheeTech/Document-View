declare interface ILibraryDocumentsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  LibraryUrlFieldLabel: string;
}

declare module 'LibraryDocumentsWebPartStrings' {
  const strings: ILibraryDocumentsWebPartStrings;
  export = strings;
}
