define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "LibraryUrlFieldLabel": "Add a library absolute url:"
  }
});