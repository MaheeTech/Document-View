/// <reference types="mocha" />

import { assert } from 'chai';

describe('LibraryDocumentsWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
