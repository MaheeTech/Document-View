declare interface IJsDisplayListStrings {
 PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  DataGroupName: string;
  Loading: string;
}

declare module 'jsDisplayListStrings' {

  const strings: IJsDisplayListStrings;
  export = strings;
}
