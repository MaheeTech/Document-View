define([], function() {
  return {
   "PropertyPaneDescription": "Manage the Display List Web Part settings.",
    "DataGroupName": "Basic Properties",
    "LocationFieldLabel": "Location",
    "Loading" : "Web part is loading ..."
  }
});