export interface IJsDisplayListWebPartProps {
  listTitle: string;
}
